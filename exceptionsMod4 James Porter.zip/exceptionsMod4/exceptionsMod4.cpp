// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

//Custom exception for divide by 0 error
class Divide_By_Zero : public std::exception {
public:
    std::string what() {
        return "Divide by zero detected: Denominator can not be 0.\n";
    }
};

//Custom exception for do custom application logic
class Do_Something_Exception : public std::exception {
public:
    std::string what() {
        return "See I made a custom exception here! Happy?";
    }
};

bool do_even_more_custom_application_logic()
{
    //Throwing a standard exception here
    throw std::exception("Throw any standard exception here");

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    return true;
}
void do_custom_application_logic()
{
    std::cout << "Running Custom Application Logic." << std::endl;

    try {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (std::exception stdExcep) {
        std::cout << "Here is a message" << std::endl;
        std::cout << stdExcep.what() << std::endl;
    }
    
    throw Do_Something_Exception();

    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
    //Check to see if the denominator is zero and throw a divide by zero error if it does
    if (den == 0.0) {
        throw Divide_By_Zero();
    }
    //Return the answer if division is done correctly
    else {
        return (num / den);
    }
}

void do_division() noexcept
{

    float numerator = 10.0f;
    float denominator = 0;

    //Added try block surrounding the divide function to check if the division will cause an error
    try {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    //Catch if there is a divide by zero error found
    catch (Divide_By_Zero dbzExcep) {
        std::cout << dbzExcep.what();
    }
    
}

int main()
{
    try {
        //Title text
        std::cout << "Exceptions Tests!" << std::endl;
        
        //Run these functions and check that they work properly
        do_division();
        do_custom_application_logic();
    }
    //Catch the custom do something exception here
    catch (Do_Something_Exception dsExcep) {
        std::cout << dsExcep.what() << std::endl;
    }
    //Catch std::ecxeption thrown here
    catch (std::exception excp) {
        std::cout << excp.what() << std::endl;
    }
    //  All uncaught exception here
    catch (...) {
        std::cout << "Caught an unknown exception here." << std::endl;
    }

    //Line that prints out when the catch block is finished
    std::cout << "It is the end!" << std::endl;
    
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu